<?php
include_once('db.php');
include_once('key.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="img/favicon2.ico" type="image/x-icon" />
    <title>IMM 2019 Grad Show</title>

    <!-- for Google -->
    <meta name="description" content="A technology charged graduate show crafted by Sheridan College's Interactive Media Management students and hosted by the award winning Jam3 Design & Experience Agency in Toronto's booming tech sector." />
    <meta name="keywords" content="Technology, Design, Jam3, Sheridan College, Graduate Show" />
    <meta name="author" content="Interactive Media Management" />

    <!-- for Facebook -->
    <meta property="og:title" content="Sheridan College's Interactive Media Management Grad Show 2019" />
    <meta property="og:url" content="http://imm.sheridanc.on.ca/openhouse/" />
    <meta property="og:type" content="website" />
    <meta property="og:description" content="A technology charged graduate show crafted by Sheridan College's Interactive Media Management students and hosted by the award winning Jam3 Design & Experience Agency in Toronto's booming tech sector." />
    <meta property="og:image" content="http://imm.sheridanc.on.ca/openhouse/img/facebookbanner.jpg" /> <!-- Facebook recommended: 1200 x 630 - ideal: 1200 x 1200 square image -->


    <!-- for Twitter -->
    <meta name="twitter:card" content="Sheridan College's Interactive Media Management Grad Show 2019" />
    <meta name="twitter:title" content="Sheridan College's Interactive Media Management Grad Show" />
    <meta name="twitter:description" content="A technology charged graduate show crafted by Sheridan College's Interactive Media Management students and hosted by the award winning Jam3 Design & Experience Agency in Toronto's booming tech sector." />
    <meta name="twitter:url" content="http://imm.sheridanc.on.ca/openhouse/" />
    <meta name="twitter:image" content="http://imm.sheridanc.on.ca/openhouse/img/twitterbanner.jpg" />
    <!-- Images for the Twitter Card should be at least 280px in width, and at least 150px in height. Image must be less than 1MB in size. Ideal is 1,024 x 512 -->

    <!--[if IE]>
        	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    	<![endif]-->

    <!--[if lt IE 9]>
		    <script src="http://css3-mediaqueries-js.googlecode.com/files/css3-mediaqueries.js"></script>
		    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    <!-- css3-mediaqueries.js for IE less than 9 -->
    <!--[if lt IE 9]>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->


    <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet"> -->
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- FONTAWESOME ICON -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- JQUERY & POPPER & BOOTSTRAP JS-->
    <script src="https://code.jquery.com/jquery-3.4.0.min.js" integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <!-- PARTICLE JS -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

    <!-- INTERNAL LINKS -->
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/main.js"></script>

</head>

<body>
    <header>
        <!-- Put your header here -->
    </header>
    <div id="particles-js"></div>
    <nav id="nav" class="navbar sticky-top navbar-expand-lg navbar-dark">
        <?php
        include_once('nav.php');
        ?>
    </nav>

    <main>
        <div class="body-particles">
            <?php
            include_once('content.php');
            ?>
        </div>
    </main>
    <a href="https://www.google.com/maps/place/Jam3/@43.6471789,-79.3946662,17z/data=!3m1!4b1!4m5!3m4!1s0x882b3504121db61b:0x87154c3940f8bd34!8m2!3d43.6471789!4d-79.3924722" target="_blank">
        <div class="container img-fluid">
            <div class="col-12" id="map">

            </div>
        </div>
    </a>
    <div class="container text-center">
        <p class="details loc">Hosted by <span>Jam3</span> &commat; 325 Adelaide Street West, Toronto</li>
        </p>
    </div>

    <!-- SCRIPT -->
    <script src="js/particle.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?= $key ?>"></script>
    <script src="js/map.js"></script>
</body>

</html>